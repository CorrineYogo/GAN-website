/* ================================================================
   YGAN WEBSITE — main.js
   Handles: navbar scroll, mobile menu, scroll-to-top button,
   gallery tabs, and smooth interactions.
   ================================================================ */

document.addEventListener('DOMContentLoaded', function () {

  // ---- NAVBAR: add .scrolled class when user scrolls ----
  const navbar = document.getElementById('navbar');
  window.addEventListener('scroll', function () {
    if (window.scrollY > 60) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
  });

  // ---- HAMBURGER MOBILE MENU ----
  const hamburger = document.getElementById('hamburger');
  const navLinks = document.getElementById('navLinks');
  if (hamburger && navLinks) {
    hamburger.addEventListener('click', function () {
      navLinks.classList.toggle('open');
    });
    // Close menu when a link is clicked
    navLinks.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        navLinks.classList.remove('open');
      });
    });
  }

  // ---- SCROLL TO TOP BUTTON ----
  const scrollTopBtn = document.getElementById('scrollTop');
  if (scrollTopBtn) {
    window.addEventListener('scroll', function () {
      if (window.scrollY > 400) {
        scrollTopBtn.classList.add('visible');
      } else {
        scrollTopBtn.classList.remove('visible');
      }
    });
    scrollTopBtn.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  // ---- GALLERY TABS (on gallery.html) ----
  // HOW TO USE: Add data-tab="photos" or data-tab="videos" to your buttons,
  // and data-type="photo" or data-type="video" to your gallery items.
  const tabs = document.querySelectorAll('.gallery-tab');
  const galleryItems = document.querySelectorAll('.gallery-full-item');
  if (tabs.length > 0) {
    tabs.forEach(function (tab) {
      tab.addEventListener('click', function () {
        tabs.forEach(function (t) { t.classList.remove('active'); });
        tab.classList.add('active');
        const filter = tab.getAttribute('data-tab');
        galleryItems.forEach(function (item) {
          if (filter === 'all' || item.getAttribute('data-type') === filter) {
            item.style.display = 'block';
          } else {
            item.style.display = 'none';
          }
        });
      });
    });
  }

  // ---- FADE IN ON SCROLL (simple intersection observer) ----
  const fadeEls = document.querySelectorAll(
    '.mission-item, .program-card, .stat-item, .gallery-item, .blog-card, .team-card, .gallery-full-item, .blog-full-card'
  );
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });

    fadeEls.forEach(function (el) {
      el.style.opacity = '0';
      el.style.transform = 'translateY(24px)';
      el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
      observer.observe(el);
    });
  }

  // ---- CONTACT FORM (basic client-side validation) ----
  // HOW TO CONNECT YOUR FORM:
  // Replace the form action with your backend URL or email service.
  // Example with Formspree: <form action="https://formspree.io/f/YOUR_ID" method="POST">
  const contactForm = document.querySelector('.contact-form form');
  if (contactForm) {
    contactForm.addEventListener('submit', function (e) {
      e.preventDefault();
      // Show a simple success message — replace this with your actual form submission logic
      const btn = contactForm.querySelector('button[type="submit"]');
      btn.textContent = 'Message Sent! ✓';
      btn.style.background = '#2d7a3a';
      btn.disabled = true;
      setTimeout(function () {
        btn.textContent = 'Send Message';
        btn.disabled = false;
        contactForm.reset();
      }, 3000);
    });
  }

});
