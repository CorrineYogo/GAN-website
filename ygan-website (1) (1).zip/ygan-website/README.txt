# YGAN Website — Setup & Customization Guide
Youth Greenspace Action and Network

---

## 📁 FILE STRUCTURE

```
ygan-website/
├── index.html          ← Homepage
├── about.html          ← About Us page
├── programs.html       ← All 5 programs detail page
├── team.html           ← Board + Staff team page
├── gallery.html        ← Photo & video gallery
├── blog.html           ← Blog posts page
├── contact.html        ← Contact form page
├── style.css           ← ALL styling (colors, layout, fonts)
├── main.js             ← ALL JavaScript (menu, scroll, tabs)
└── images/             ← PUT ALL YOUR IMAGES HERE
    ├── logo.png
    ├── hero-bg.jpg
    ├── about-photo.jpg
    ├── program1.jpg ... program5.jpg
    ├── gallery1.jpg ... gallery9.jpg
    ├── blog1.jpg ... blog4.jpg
    ├── hurdson-thomas.jpg
    ├── alphonce-muiya.jpg
    ├── ... (all team photos)
    └── (any other images)
```

---

## 🖼️ HOW TO ADD IMAGES

### Step 1: Create an images/ folder
In the same folder as your HTML files, create a folder called `images`.

### Step 2: Add your images
Copy your photos into the `images/` folder.

### Step 3: Update the image paths in the HTML files
Open the relevant HTML file in a text editor (Notepad, VS Code, etc.)
Find the `<img src="images/FILENAME.jpg">` tag and change the filename.

---

## 🌿 HERO BACKGROUND PHOTO (Tree Planting Photo)

Open `style.css` and find:
```css
.hero {
  background-image: url('images/hero-bg.jpg');
```
Change `hero-bg.jpg` to your actual photo filename.
Example: `background-image: url('images/tree-planting-day.jpg');`

---

## 🃏 PROGRAM CARD BACKGROUND IMAGES

Open `style.css` and find each `.program-bg-X` rule:
```css
.program-bg-1 { background-image: url('images/program1.jpg'); }
.program-bg-2 { background-image: url('images/program2.jpg'); }
.program-bg-3 { background-image: url('images/program3.jpg'); }
.program-bg-4 { background-image: url('images/program4.jpg'); }
.program-bg-5 { background-image: url('images/program5.jpg'); }
```
Change each URL to your chosen photo.

---

## 👥 TEAM MEMBER PHOTOS

Open `team.html` and find each team member card.
Each card has: `<img src="images/hurdson-thomas.jpg" ...>`
Replace the filename with the actual photo you've saved in the `images/` folder.

Name your photos clearly:
- hurdson-thomas.jpg
- alphonce-muiya.jpg
- sheila-anyango.jpg
- peter-nguka.jpg
- boniface-otiambo.jpg
- ann-wangari.jpg
- brian-orwa.jpg
- rennie-chengori.jpg
- mourine-nyabuto.jpg
- esther-chepngetich.jpg
- petronila-adhiambo.jpg
- gloria-besha.jpg
- kelvin-njuguna.jpg
- james-musau.jpg
- millicent-abiyah.jpg
- lennox-caleb.jpg

---

## 📸 GALLERY IMAGES

Open `gallery.html` and `index.html`.
Find `<img src="images/gallery1.jpg">` etc.
Replace each with your actual photo.

To add more photos: copy one `.gallery-full-item` block and paste it.

---

## 🎬 ADDING YOUTUBE VIDEOS (Gallery)

In `gallery.html`, find the video block:
```html
<iframe src="https://www.youtube.com/embed/YOUR_VIDEO_ID_1" ...>
```
Replace `YOUR_VIDEO_ID_1` with the actual YouTube video ID.

The video ID is the part after `?v=` in a YouTube URL.
Example: https://www.youtube.com/watch?v=**dQw4w9WgXcQ**
Use: `https://www.youtube.com/embed/dQw4w9WgXcQ`

---

## 📱 SOCIAL MEDIA LINKS

In any HTML file, find the footer's `<div class="social-links">`.
Replace each `href="#"` with your actual URL:
```html
<a href="https://facebook.com/YourPage" ...>
<a href="https://twitter.com/YourHandle" ...>
<a href="https://instagram.com/YourHandle" ...>
<a href="https://linkedin.com/company/YourOrg" ...>
<a href="https://youtube.com/@YourChannel" ...>
```
Do this in ALL 7 HTML files (index, about, programs, team, gallery, blog, contact).

---

## 📝 ADDING BLOG POSTS

Open `blog.html`. Find a `.blog-full-card` block.
Copy the entire block (from `<article class="blog-full-card">` to `</article>`).
Paste it before the closing `</div>` of `.blog-full-grid`.
Update the image, date, category, title, content, and author.

---

## 🎨 CHANGING BRAND COLORS

Open `style.css`. At the top, find `:root { }`:
```css
:root {
  --green: #2d7a3a;        ← Main green
  --green-dark: #1e5427;   ← Dark green
  --green-light: #4caf65;  ← Light green accent
  --brown: #6b3f1e;        ← Brown accent
}
```
Change any hex color code to your preferred color.

---

## 📧 CONNECTING THE CONTACT FORM

The easiest free option is Formspree:
1. Go to https://formspree.io
2. Sign up for a free account
3. Create a new form — you'll get a form ID like `xabcdefg`
4. Open `contact.html`, find `<form>` and change it to:
   `<form action="https://formspree.io/f/YOUR_FORM_ID" method="POST">`
5. Done! You'll receive emails when someone submits the form.

---

## 🌐 HOSTING THE WEBSITE

To put this website live, you need web hosting. Recommended free/cheap options:
- **Netlify** (free): Drag and drop your folder at netlify.com
- **GitHub Pages** (free): Push to GitHub and enable Pages
- **Hostinger** (paid, ~$3/month): Works with your greenspaceaction.org domain

---

## ✅ CHECKLIST BEFORE GOING LIVE

- [ ] Logo added to images/logo.png
- [ ] Hero background photo added (tree planting)
- [ ] All 5 program card images added
- [ ] All gallery photos added
- [ ] All team member photos added
- [ ] Blog post images added
- [ ] Social media links updated in all 7 pages
- [ ] Contact form connected (Formspree or similar)
- [ ] Domain pointed to hosting

---

Questions? Contact: info@greenspaceaction.org
